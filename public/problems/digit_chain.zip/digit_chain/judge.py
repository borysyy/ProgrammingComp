#!/usr/bin/env python3
import sys

DEBUG = False # set True for extra output

all_lines = open(sys.argv[1], 'r').read().split('\n')
while all_lines[-1].strip() == '':
    all_lines.pop()
lib_size = int(all_lines[0])
data = all_lines[1].split(' ')

lib = set(data)

score = 0


#grab all the input
solution = []
try:
    s = input()
except:
    s = None

while s != None:
    solution += s.split()
    try:
        s = input()
    except:
        s = None

if len(solution) == 0:
    print(0)
    sys.exit()

#make sure the first one is in valid
s = solution[0]
if s == None or s not in lib:
    print(score)
    sys.exit()

lib.remove(s)

score += 1
prev_s = s

while score < len(solution):
    s = solution[score]

    # give up if the string isn't in the library
    if s not in lib:
        break

    lib.remove(s)


    # check whether the two strings differ by 1 digit only
    if len(prev_s) == len(s):
        # count different digits
        cnt = 0
        for x,y in zip(prev_s, s):
            if x != y:
                cnt += 1
        if cnt != 1:
            break # just return old score
        score += 1
    elif len(prev_s) + 1 == len(s):
        # new string has 1 extra digit somewhere, but everything else should be the same
        i, j, cnt = 0, 0, 0
        while cnt <= 1 and i < len(prev_s) and j < len(s):
            if prev_s[i] == s[j]:
                i += 1
                j += 1
            else:
                # found new digit in s, so skip it
                j += 1
                cnt += 1
        if cnt <= 1:
            score += 1
        else:
            break
    elif len(prev_s) == len(s) + 1:
        # old string has 1 extra digit somewhere, but everything else should be the same
        i, j, cnt = 0, 0, 0
        while cnt <= 1 and i < len(prev_s) and j < len(s):
            if prev_s[i] == s[j]:
                i += 1
                j += 1
            else:
                # found extra digit in prev_s, so skip it
                i += 1
                cnt += 1
        if cnt <= 1:
            score += 1
        else:
            break

    prev_s = s

print(score)
