#!/usr/bin/env python3

import sys
import argparse
import random

DEBUG = True

parser = argparse.ArgumentParser(
	description = 'Generates a random digit-chain library given its parameters.',
	formatter_class=argparse.ArgumentDefaultsHelpFormatter
	)
parser.add_argument('-m', '--min', type = int, default = 3, help = 'Integer minimum length of strings > 0')
parser.add_argument('-M', '--max', type = int, default = 4, help = 'Integer maximum length of strings <= 20')
parser.add_argument('-d', '--dups', type = int, default = 50, help = 'Integer target number of duplicate mutation attempts to generate before stopping')
parser.add_argument('-r', '--retries', type = int, default = 5, help = 'Integer maximum attempts to avoid duplicate mutation before giving up on parent')
parser.add_argument('-s', '--seeds', type = int, default = 20, help = 'Integer number of random initial library entries > 0')
parser.add_argument('-o', '--outfile', type = argparse.FileType('w'), default = 'lib.dat', help = 'Output file name')
args = parser.parse_args()

arg_errors = False

if args.min <= 0:
	print('\nmin must be > 0')
	arg_errors = True

if args.max > 20:
	print('\nmax must be <= 20')
	arg_errors = True

if args.min > args.max:
    print('\nmin must be <= max')
    arg_errors = True

if args.seeds <= 0:
	print('\nseeds must be > 0')
	arg_errors = True

if args.outfile.closed:
	print('\nThe file is closed for some reason')
	arg_errors = True

if arg_errors:
	print('')
	parser.print_help()
	sys.exit(1)

min = args.min
max = args.max
dups = args.dups
retries = args.retries
seeds = args.seeds
f = args.outfile

lib = set()
digits = ['0','1','2','3','4','5','6','7','8','9']
for i in range(seeds):
    s = [None] * random.randint(min, max)
    for j in range(len(s)):
        s[j] = random.choice(digits)
    lib.add(''.join(s))

lib_dups = set()
while len(lib_dups) < dups:
    # pick a random element in the library
    parent = random.choice(tuple(lib))

    CHANGE_DIGIT = 0
    DEL_DIGIT = 1
    ADD_DIGIT = 2

    mut_choices = []
    mut_choices += [CHANGE_DIGIT]
    mut_choices += [DEL_DIGIT] if len(parent) > min else []
    mut_choices += [ADD_DIGIT] if len(parent) < max else []

    tries = 0
    done = False
    while not done and tries < retries:
        oldlen = len(lib)

        # random choice of mutation
        mutator = random.choice(mut_choices)
        if mutator == CHANGE_DIGIT:
            # change a digit
            index = random.randint(0, len(parent) - 1)
            c = int(parent[index])
            child = parent[:index] + random.choice(digits[:c] + digits[c + 1:]) + parent[index + 1:]
        elif mutator == DEL_DIGIT:
            index = random.randint(0, len(parent) - 1)
            child = parent[:index] + parent[index + 1:]
        elif mutator == ADD_DIGIT:
            index = random.randint(0, len(parent)) # possible to pick past the end
            child = parent[:index] + random.choice(digits) + parent[index:]

        lib.add(child)
        if oldlen < len(lib):
            # this is a unique string
            done = True
        else:
            oldlen = len(lib_dups)
            if child < parent:
                lib_dups.add(child + ' to ' + parent)
            else:
                lib_dups.add(parent + ' to ' + child)
            if oldlen < len(lib_dups):
                done = True

        tries += 1

if DEBUG:
    print(lib)
    print(len(lib))
    print('DUPS:')
    for i in list(lib_dups):
        print(i)

f.write(str(len(lib)) + '\n')
lib_list = list(lib)
random.shuffle(lib_list)
for x in lib_list:
    f.write(x)
    if x != lib_list[-1]:
        f.write(' ')
f.write('\n')
