import random
import sys

DICE_CNT = 5

for test in range(int(sys.argv[1])):
    dice = [str(random.randint(1,6)) for i in range(DICE_CNT)]
    result = str(random.randint(1,20)) # sum of two 20-sided die
    print(' '.join(dice + [result]))
