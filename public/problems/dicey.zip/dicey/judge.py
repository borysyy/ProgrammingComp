import sys

DEBUG = True

parens = '()'
operators = '+-*/%'

tests = [lines.split(' ') for lines in open(sys.argv[1]).read().split('\n') if lines]

score = 0
lineno = 0

for lineno in range(len(tests)):
    try:
        s = input()
    except:
        break

    if s == 'pass':
        continue

    s = list(s)

    dice = tests[lineno][:]
    desired_result = int(dice[-1])
    dice = dice[:-1]


    ok_so_far = True
    prev_was_digit = False
    for c in s:
        if c in parens:
            prev_was_digit = False
        elif c in operators:
            prev_was_digit = False
        elif c in dice and prev_was_digit == False:
            prev_was_digit = True
            dice.remove(c)
        else:
            ok_so_far = False
            break

    if not ok_so_far:
        continue

    s = ''.join(s)
    s = s.replace('/', '//')
    try:
        result = eval(s)
    except:
        result = -1

    if result == desired_result:
        score += 1


print(score)
